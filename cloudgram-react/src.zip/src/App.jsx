import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Feed from './components/Feed';
import Upload from './components/Upload';

function App() {
  return (
    <Router>
      <div className="app-container">
        <Navbar />
        
        <div className="content">
          <Routes>
            {/* Pattern 3: Decoupled UI components managed by client-side routing */}
            <Route path="/" element={<Feed />} />
            <Route path="/upload" element={<Upload />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;